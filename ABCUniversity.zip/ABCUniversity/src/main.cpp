//Aaron Fehir
//April 23, 2021
//Data Structures and Analysis
//Project Two

//Include MenuOptions class
#include "MenuOptions.h"

//Declare and define main function
int main() {

	//Instantiate MenuOptions class object
	MenuOptions menu;

	//Call DiplayMenu function from MenuOptions class
	menu.DisplayMenu();
	return 0;
}




