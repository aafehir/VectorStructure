//Aaron Fehir
//April 23, 2021
//Data Structures and Analysis
//Project Two

#ifndef SRC_MENUOPTIONS_H_
#define SRC_MENUOPTIONS_H_

//Create MenuOptions class
class MenuOptions {

//Declare public function
public:
  void DisplayMenu();

//Declare private variable
private:
  char selection;

};

#endif /* SRC_MENUOPTIONS_H_ */
