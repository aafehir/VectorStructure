//Aaron Fehir
//April 23, 2021
//Data Structures and Analysis
//Project Two

#ifndef PRINTCOURSELIST_H_
#define PRINTCOURSELIST_H_

class PrintCourseList {

public:
	void printSampleSchedule();
};


#endif /* PRINTCOURSELIST_H_ */
