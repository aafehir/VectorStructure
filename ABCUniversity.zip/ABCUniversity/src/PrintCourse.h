//Aaron Fehir
//April 23, 2021
//Data Structures and Analysis
//Project Two

#ifndef PRINTCOURSE_H_
#define PRINTCOURSE_H_

#include <string>
using namespace std;

class PrintCourse {

public:
	void printCourseInformation(string name);

};



#endif /* PRINTCOURSE_H_ */
